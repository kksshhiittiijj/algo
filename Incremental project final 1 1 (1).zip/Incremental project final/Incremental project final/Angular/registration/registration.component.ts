import { Component, OnInit } from '@angular/core';
import { AuthService } from '../services/auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent {
username: string="";
password: string="";
confirmPassword: string="";
role: string="";
passwordMismatch: boolean=false;
  constructor(private authService: AuthService, private router: Router) { }

  ngOnInit(): void {
  }
register(): void{
  if(this.password !==this.confirmPassword){
    this.passwordMismatch=true;
    return;
  }
  this.passwordMismatch=false;
  if(!this.isPasswordComplex(this.password)){
    return;
  }
  console.log("***********Trying to register from component**************")
  console.log("Username "+this.username+" Password "+this.password +" Role "+this.role);
  let user: object=this.authService.register(this.username, this.password, this.role)
  if(user){
    console.log("*********registration.ts*********");
    console.log(user);
    this.router.navigate(['/login']);
  }
  else{
    this.router.navigate(['/error']);
  }
}
isPasswordComplex(password: string): boolean{
  const hasUppercase=/[A-Z]/.test(password);
  const hasLowercase=/[a-z]/.test(password);
  const hasDigit=/\d/.test(password);
  const hasSpecialChar=/[!@#$%^&*()_+{}\[\]:;<>,.?~\-]/.test(password);
  return hasUppercase && hasLowercase && hasDigit && hasSpecialChar;
}
}
