import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Player } from 'src/models/player.model';

@Injectable({
  providedIn: 'root'
})
export class OrganizerService {
private baseUrl='https://ide-febabebbdbcd314719766eabbabbfone.premiumproject.examly.io/proxy/8080';
  constructor(private httpClient:HttpClient) { }
  public getUnsoldPlayers():Observable<any>{
    return this.httpClient.get(this.baseUrl+"/api/organizer/unsold-players");
  }
  public getPlayersByCategory(category:string):Observable<any>{
    return this.httpClient.get(this.baseUrl+"/api/organizer/player-list/category/"+category);
  }
  public assignPlayerToTeam(teamId:number,player:Player):Observable<any>{
    console.log(teamId);
    return this.httpClient.post(this.baseUrl+"/api/organizer/assign-player?teamId="+teamId+"&playerId="+player.id,"");
  }
  public releasePlayerFromTeam(playerId:number):Observable<any>{
    return this.httpClient.put(this.baseUrl+"/api/organizer/release-player/"+playerId,"");
  }
  public getAllTeams():Observable<any>{
    return this.httpClient.get(this.baseUrl+"/api/organizer/team-list");
  }
  public getPlayerByTeamId(teamId:number):Observable<any>{
    return this.httpClient.get(this.baseUrl+"/api/organizer/player-list/"+teamId);
  }
}
