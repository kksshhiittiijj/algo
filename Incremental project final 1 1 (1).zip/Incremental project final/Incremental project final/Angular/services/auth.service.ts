import { HttpClient } from '@angular/common/http';
import { Injectable, OnInit } from '@angular/core';
import { BehaviorSubject, Observable, of } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AuthService implements OnInit {
  private currentUserSubject: BehaviorSubject<string | null>;
  public currentUser: Observable<string | null>;
  private baseUrl='https://ide-febabebbdbcd314719766eabbabbfone.premiumproject.examly.io/proxy/8080/';
  private userRoleSubject=new BehaviorSubject<string>('');
  userRole$:Observable<string>=this.userRoleSubject.asObservable();
  private isAuthenticatedSubject:BehaviorSubject<boolean>=new BehaviorSubject<boolean>(this.isAuthenticated());
  isAuthenticated$=this.isAuthenticatedSubject.asObservable();

  registeredUsers:any[]=[];
  constructor(private http:HttpClient) {
    this.currentUserSubject=new BehaviorSubject<string | null>(
      localStorage.getItem('currentUser')
    );
    this.currentUser=this.currentUserSubject.asObservable();
   }

   ngOnInit(): void {
     const localdata=localStorage.getItem('registeredUsers');
     if(localdata != null){
      this.registeredUsers=JSON.parse(localdata);
     }
   }
   register(username: string, password: string, role:string):
   object{
    const body:object={username: username,password: password, role:role};
    console.log("**********auth.service.ts**********"+body);
    console.log(body);
    this.registeredUsers.push(body);

    localStorage.setItem('registeredUser',JSON.stringify(this.registeredUsers));
    return body;
   }
   login(username: string,password:string, role:string):Object{
    console.log("2.auth.service");
    const loginData={username: username,password: password, role: role};
    console.log(loginData);
    const isuserexist=this.registeredUsers.find(u=>u.username==loginData.username && u.password==loginData.password)
    console.log("3.check if user exist");
    console.log(isuserexist);
    if(isuserexist!=undefined){
      return true;
    }
    else{
      return false;
    }
   }
   isLoggedIn():boolean{
    console.log(localStorage.getItem('role'));
    return !!localStorage.getItem('role');
   }
   private handleError<T>(operation='operation',result?:T){
    return (error: any):Observable<T>=>{
      console.error(error);
      return of(result as T);
    };
   }

   logout():void{
    localStorage.removeItem('token');
    localStorage.removeItem('currentUser');
    localStorage.removeItem('role');
    this.currentUserSubject.next(null);
   }
   isAuthenticated():boolean{
    const token=localStorage.getItem('role');
    console.log(token);
    return !!token;
   }
   isAdmin():boolean{
    const token=localStorage.getItem('role');
    console.log(token);
    if(token==='ADMIN'){
      return true;
    }
    return false;
   }
   isOrganizer():boolean{
    const token=localStorage.getItem('role');
    if(token==='ORGANIZER'){
      console.log("token:"+token);
      return true;
    }
    return false;
   }
}
