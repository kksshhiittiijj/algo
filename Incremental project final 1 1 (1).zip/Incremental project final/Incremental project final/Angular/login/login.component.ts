import { Component, OnInit } from '@angular/core';
import { AuthService } from '../services/auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {
username: string="";
password: string="";
role: string="";
error: string='';
  constructor(private authService: AuthService,private router: Router) { }

  ngOnInit(): void {
    console.log('init login')
  }
  login():void{
    let loginuser={username : this.username, password: this.password, role: this.role};
    console.log("*******1. login.ts*************");
    console.log(loginuser);
    let isloginuser=this.authService.login(this.username,this.password,this.role);
    console.log("isLoginuser");
    console.log(isloginuser);
    if(isloginuser){
      const role=loginuser.role;
      console.log("4.login.component :role-");
      console.log(role);
      if(role){
        if(role==='ADMIN'){
          this.router.navigate(['/admin']);
        }
        else if(role === 'ORGANIZER'){
          this.router.navigate(['/organizer']);
        }else{}
      }else{}
    }
  }
}

  
