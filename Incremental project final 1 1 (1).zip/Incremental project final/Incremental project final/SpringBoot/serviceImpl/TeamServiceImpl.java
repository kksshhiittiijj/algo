package com.examly.springapp.service.serviceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.examly.springapp.entity.Player;
import com.examly.springapp.entity.Team;
import com.examly.springapp.repository.TeamRepo;
import com.examly.springapp.service.TeamService;

@Service
public class TeamServiceImpl implements TeamService {
    

    @Autowired
    private TeamRepo repo;

    public Team addTeam(Team team){
        if(!repo.existsById(team.getId())){
            return repo.save(team);
        }else{
            return null;
        }
    }

    public Team updateById(Team team){
        if(repo.existsById(team.getId())){
            return repo.save(team);
        }else{
            return null;
        }

    }

    public List<Team> getAll(){
        return repo.findAll();
    }

    public Team getById(long teamId){
        if(repo.existsById(teamId)){
            return repo.findById(teamId).get();
        }
        return null;
    }

    public Boolean deleteById(long teamId){
        if(repo.existsById(teamId)){
            repo.deleteById(teamId);
            return true;
        }
        return false;
    }


}
