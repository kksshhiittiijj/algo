package com.examly.springapp.service.serviceImpl;
 
import java.util.List;
 
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
 
import com.examly.springapp.entity.Player;
import com.examly.springapp.entity.Team;
import com.examly.springapp.repository.PlayerRepo;
import com.examly.springapp.repository.TeamRepo;
import com.examly.springapp.service.OrganizerService;
@Service
public class OrganizerServicesImpl implements OrganizerService {
    @Autowired
    private PlayerRepo prepo;
    @Autowired
    private TeamRepo trepo;
 
    @Override
    public boolean assignPlayerToTeam(Long playerId, Long teamId) {
        if(prepo.existsById(playerId) && trepo.existsById(teamId)){
            Player p = prepo.findById(playerId).get();
            Team t = trepo.findById(teamId).get();
            t.addPlayer(p);
            p.setSold(true);
            p.setTeam(t);
            prepo.save(p);
           
            return true;
        }
        return false;
    }
    @Override
    public List<Player> getPlayerListByTeamId(long teamId) {
   
        if(trepo.existsById(teamId)){
            return prepo.findByTeamId(teamId);
        }
        return null;
    }
    @Override
    public List<Player> getSoldPlayers() {
        return prepo.findBySoldTrue();
    }
    @Override
    public List<Player> getUnsoldPlayers() {
       
        return prepo.findBySoldFalse();
    }
    @Override
    public boolean releasePlayerFromTeam(Long playerId) {
        if(prepo.existsById(playerId)){
             Player p = prepo.findById(playerId).get();
             p.setTeam(null);
             p.setSold(false);
             prepo.save(p);
            return true;
        }
        return false;
       
    }

    public List<Player> getDataByCategory(String category){
        if(category.equals("All")){
            return prepo.findAll();
        }else{
            return prepo.findByCategory(category);
        }
    }

    public List<Team> getAllTeams(){
        return trepo.findAll();
    }
 
 

}