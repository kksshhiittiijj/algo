package com.examly.springapp.service.serviceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.examly.springapp.entity.Player;
import com.examly.springapp.entity.Team;
import com.examly.springapp.repository.PlayerRepo;
import com.examly.springapp.service.PlayerService;

@Service
public class PlayerServiceImpl implements PlayerService{

    @Autowired
    private PlayerRepo playerRepo;

    public Player addPlayer(Player player){
        if(!playerRepo.existsById(player.getId())){
            player.setSold(false);
            return playerRepo.save(player);
        }
        else{
            return null;
        }
    }

    public List<Player> getAllPlayer(){
        return playerRepo.findAll();
    }

    public Player getById(long id){
        if (playerRepo.existsById(id)) {
            return playerRepo.findById(id).get();   
        }
        return null;
    }

    public Boolean deleteById(long id){
        if(playerRepo.existsById(id)){
            playerRepo.deleteById(id);
            return true;
        }
        return false;
    }

    public Player updatePlayerById(Player p,long id){
        if(playerRepo.existsById(id)){
          p.setId(id);
            playerRepo.save(p);
            return p;
        }
        return null;

    }


}
