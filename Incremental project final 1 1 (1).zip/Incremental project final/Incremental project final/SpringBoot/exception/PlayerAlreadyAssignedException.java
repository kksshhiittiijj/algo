package com.examly.springapp.exception;

public class PlayerAlreadyAssignedException extends RuntimeException {
    public PlayerAlreadyAssignedException(String str){
        super(str);
    }
}
