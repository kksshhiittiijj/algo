package com.examly.springapp.controller;
 
import java.util.List;
 
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
 
import com.examly.springapp.entity.User;
import com.examly.springapp.service.UserService;
 
@RestController
@CrossOrigin(allowedHeaders = "*",origins = "*")
public class UserController {
   
    @Autowired
    UserService userService;
 
    @PostMapping("/api/user/register")
    public User userRegister(@RequestBody User register){
        User u = userService.registerUser(register);
        System.out.println(register);
        if (u!=null) {
                System.out.println(u);          
                return u;  
        }
        return null;
    }
   
    @PostMapping("/api/user/login")
    public ResponseEntity<Boolean> userLogin(@RequestBody User login){
        User u = userService.loginUser(login);
        if(u.getPassword().equals(login.getPassword())){
            System.out.println(u.getPassword());
            return new ResponseEntity<>(true,HttpStatus.OK);
        }
       
        return new ResponseEntity<>(false,HttpStatus.INTERNAL_SERVER_ERROR);
    }
 
    @GetMapping("/api/user")
    public List<User> getUser(){
        List<User> list = userService.getAllUser();
        if(list.size()>0){
            return list;
        }
        return null;
    }
 
 
 
}