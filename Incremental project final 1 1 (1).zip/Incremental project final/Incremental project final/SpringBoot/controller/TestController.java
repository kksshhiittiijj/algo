package com.examly.springapp.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.examly.springapp.entity.Team;
import com.examly.springapp.service.TeamService;

@RestController
@CrossOrigin(allowedHeaders = "*",origins = "*")
public class TestController {
        @Autowired
    private TeamService service;

    @GetMapping("api/test/welcome")
    public String welcome(){
        return "Welcome to Spring Boot Project";
    }

    @GetMapping("api/test/team")
    public List<Team> getTeam(){
        List<Team> list = new ArrayList<>();
        return list;
    }

}
