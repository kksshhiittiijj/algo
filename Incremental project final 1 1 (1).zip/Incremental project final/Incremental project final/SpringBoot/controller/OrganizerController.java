package com.examly.springapp.controller;
 
import java.util.List;
 
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
 
import com.examly.springapp.entity.Player;
import com.examly.springapp.entity.Team;
import com.examly.springapp.exception.PlayerAlreadyAssignedException;
import com.examly.springapp.service.OrganizerService;
 
@RestController
@CrossOrigin(allowedHeaders = "*",origins = "*")
public class OrganizerController {
    @Autowired
    private OrganizerService service;
 
   @GetMapping("api/organizer/sold-players")
    public List<Player> getSoldPlayers(){
        List<Player>p=service.getSoldPlayers();
       
        return p;
   
    }
 
    @PostMapping("api/organizer/assign-player")
    public boolean assignPlayer(@RequestParam Long playerId,@RequestParam Long teamId) throws Exception
    {
        boolean b = service.assignPlayerToTeam(playerId, teamId);
 
        if(b){
            return b ;
        }
 
       throw new PlayerAlreadyAssignedException("Player already assigned");
    }
 
    @GetMapping("api/organizer/unsold-players")
    public List<Player> getUnSoldPlayers(){
        List<Player>p=service.getUnsoldPlayers();
       
        return p;
   
    }
 
    @PutMapping("api/organizer/release-player/{playerId}")
    public boolean releasePlayer(@PathVariable Long playerId){
       
       
        return service.releasePlayerFromTeam(playerId);
       
       
    }
 
    @GetMapping("api/organizer/player-list/{teamId}")
    public List<Player> specificTeamId(@PathVariable Long teamId)
    {
        List<Player> p =service.getPlayerListByTeamId(teamId);
       
        return p;
   
    }
 
    @GetMapping("api/organizer/player-list/category/{category}")
    public List<Player> categoryPlayerList(@PathVariable String category){
        List<Player> l = service.getDataByCategory(category);
        return l;
    }

    @GetMapping("api/organizer/team-list")
        public List<Team> getAllTeam(){
            return service.getAllTeams();

    }

  
   
}