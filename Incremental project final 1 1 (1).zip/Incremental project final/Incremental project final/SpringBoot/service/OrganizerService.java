package com.examly.springapp.service;

import java.util.List;

import com.examly.springapp.entity.Player;
import com.examly.springapp.entity.Team;

public interface OrganizerService {

    List<Player> getUnsoldPlayers();
    List<Player> getSoldPlayers();
    boolean assignPlayerToTeam(Long playerId,Long teamId);
    boolean releasePlayerFromTeam(Long playerId);
    List<Player>getPlayerListByTeamId(long teamId);
    List<Player> getDataByCategory(String category);
    List<Team> getAllTeams();
    
}
