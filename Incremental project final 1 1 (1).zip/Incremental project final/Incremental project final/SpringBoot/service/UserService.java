package com.examly.springapp.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.examly.springapp.entity.User;
@Service
public interface UserService {
    
    User registerUser(User user);
    List<User> getAllUser();
    User loginUser(User user);
}
