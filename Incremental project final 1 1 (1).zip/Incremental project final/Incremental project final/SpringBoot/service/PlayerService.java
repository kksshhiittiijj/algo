package com.examly.springapp.service;

import java.util.List;
import org.springframework.stereotype.Service;
import com.examly.springapp.entity.Player;

@Service
public interface PlayerService {

      Player addPlayer(Player player);
      List<Player> getAllPlayer();
      Player getById(long id);
      Boolean deleteById(long id);
      Player updatePlayerById(Player t,long id);
}
